# Bếp Sen - Quản lý nhà hàng
Webapp quản lý nhà hàng full 8 màn hình theo thiết kế.

## Tính năng
- Tổng quan: doanh thu, đơn, bàn, món bán chạy
- Sơ đồ bàn 12 bàn realtime
- Gọi món & thanh toán: gửi bếp, VAT 8%, giảm giá
- Màn hình bếp Kanban
- Thực đơn: tạm ngưng món
- Kho nguyên liệu: cảnh báo sắp hết
- Đặt bàn: tìm bàn trống
- Nhân viên & Báo cáo

## Deploy GitHub Pages
1. Tạo repo mới trên github.com
2. Upload index.html này
3. Settings > Pages > Deploy from branch: main / root

Truy cập: https://<username>.github.io/<repo>/
